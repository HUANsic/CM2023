/**
 * @file pro_name.h
 *
 */

#ifndef PRO_NAME_H
#define PRO_NAME_H

#ifdef __cplusplus
extern "C" {
#endif
#define PRJ_NAME "Simulator (C/C++)"
#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PRO_NAME_H */
